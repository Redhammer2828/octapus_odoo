from odoo import models, fields, api

class ProductTemplate(models.Model):
    _inherit = 'product.template'

    brand_id = fields.Many2one('product.brand', string='Brand')
    article_no = fields.Char(string='Article No', copy=False, index=True, required=True)
    discount_price = fields.Float(string='Discount Price')

    _sql_constraints = [
        ('unique_article_no', 'unique(article_no)', 'Article No must be unique!')
    ]
