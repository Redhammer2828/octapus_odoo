{
    'name': 'Brand',
    'version': '1.0',
    'summary': 'Module for managing brands and vendors in Odoo',
    'description': 'This module adds functionality to manage brands and vendors in Odoo.',
    'author': '4S',
    'depends': ['base', 'product', 'purchase'],
    'data': [
        'security/ir.model.access.csv',
        'views/product_brand.xml',
        'views/product_template_view.xml',
    ],
    'installable': True,
    'auto_install': False,
}
